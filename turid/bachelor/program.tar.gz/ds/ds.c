#include "ds.h"

#include <stdlib.h>
#include <string.h>

/*** Function to read a text message from the given file pointer and store it
     in the given character array. ***/
void read_message(char* message, unsigned int* length, FILE* input, char* sig_header) {
	int i = 0;
	unsigned int header_len = strlen(sig_header);
	while (i < *length-1 && !feof(input)) {
		i += fread(&(message[i]), sizeof(char), 1, input);
		if (i >= header_len) { // look for signature header
			if (strcmp(sig_header, &(message[i-header_len])) == 0) {
				i = i-header_len;
				break; // break because signature is found
			}
		}
	} // keep reading until buffer is full or end of file is reached
	if (i == *length-1 && !feof(input)) {
		fprintf(stderr,"Message is too long.\n");
		exit(1);
	} // exit with error message if message does not fin in the buffer
	*length = i;
	message[*length] = '\0';
}

/*** Function to read signature from the given file pointer and store it
     in the given GMP integer. ***/
void read_signature(mpz_t signature, FILE* input) {
	if (feof(input)) {
		fprintf(stderr,"No signature present in input.\n");
		exit(1);
	}
	mpz_inp_str(signature, input, 16);
}

