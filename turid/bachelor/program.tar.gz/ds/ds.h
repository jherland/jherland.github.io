#ifndef DS_H
#define DS_H

#include <gmp.h>
#include <stdio.h>

/*** Function to read a text message from the given file pointer and store it
     in the given character array.
     The given length is the maximum number of characters that can be put into
     the array. If the given text message is too long, the function will abort
     the program with an error message. When read_message returns, the length
     parameter will be set to the actual number of characters copied into the
     array. ***/
void read_message(char* message, unsigned int* length, FILE* input, char* sig_header);

/*** Function to read signature from the given file pointer and store it
     in the given GMP integer.
     NOTE: The file pointer must already point to the beginning of the
     signature. This normally means that it has already been passed through
     read_message ***/
void read_signature(mpz_t signature, FILE* input);

#endif // DS_H
