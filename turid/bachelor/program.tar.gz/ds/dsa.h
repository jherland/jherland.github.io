#ifndef DSA_H
#define DSA_H

#include <gmp.h>

#define KEYSIZE 1024
#define PUBLIC_FILE "dsa_public.key"
#define PRIVATE_FILE "dsa_private.key"

// message must be < 100K
#define MAX_MESSAGE_SIZE (100*1024)
#define SIGNATURE_HEADER "\n-----BEGIN DSA SIGNATURE-----\n"

/*** Function to read in keys from file ***/
void input_key (mpz_t part1, mpz_t part2, mpz_t part3, mpz_t part4, const char* filename);

/*** Function to write keys out to file ***/
void output_key (const char* filename, const mpz_t part1, const mpz_t part2, const mpz_t part3, const mpz_t part4);


#endif // DSA_H
