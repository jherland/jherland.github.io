#include <stdio.h>

#include "dsa.h"
#include "random.h"
#include "hash.h"

int main (int argc, char* argv[]) {
	/*** Declarations ***/
	int gg, n, b, C, N, k, l;
	unsigned int s_size = 200;
	char s[200];
	FILE* generate;
	mpz_t S, base, g2, U, q, W, X, p, g, a, ga, x, y, z;
	gmp_randstate_t rand;

	/*** Initialization of variables ***/
	mpz_init(S);
	mpz_init(base);
	mpz_init(g2);
	mpz_init(U);
	mpz_init(q);
	mpz_init(W);
	mpz_init(X);
	mpz_init(p);
	mpz_init(g);
	mpz_init(a);
	mpz_init(ga);
	mpz_init(x);
	mpz_init(y);
	mpz_init(z);

	/*** Initialization of the random number generator ***/
	gmp_randinit_default(rand);
	gmp_randseed_ui(rand, generate_seed());

	/*** Generate q (order of subgroup) ***/
	mpz_ui_pow_ui(base, 2, 160); // base = 2^160
step1:
	do {mpz_urandomb(S, rand, 200);} while (mpz_cmp(S, base) < 0);
		// choose a value S at random such that S is at least 161 bits
	gg = mpz_sizeinbase(S, 2); // gg = length of S in bits
	mpz_ui_pow_ui(g2, 2, gg); // g2 = 2^gg
// step2
	mpz_export((void*) s, &s_size, 1, 1, 0, 0, S); // export S to string s (so that S can be hashed)
	hash(x, s, s_size); // x = SHA(S)
	mpz_add_ui(y, S, 1); // y = S + 1
	mpz_mod(y, y, g2); // y = y mod g2 = (S + 1) mod 2^gg
	s_size = 200;
	mpz_export((void*) s, &s_size, 1, 1, 0, 0, y); // export S+1 mod 2^gg to string s
	hash(z, s, s_size); // z = SHA(S+1 mod 2^gg)
	mpz_xor(U, x, z); // U = x xor z = SHA(S) xor SHA(S+1 mod 2^gg)
// step3
	mpz_setbit(U, 159); // set msb of U to 1
	mpz_setbit(U, 0); // set lsb of U to 1
	mpz_set(q, U); // q = U
// step4 and step5
	if (mpz_probab_prime_p(q, 50) == 0) goto step1;


	/*** Generate p (size of field) ***/
	n = (KEYSIZE-1)/160; // set n in: KEYSIZE-1 = 106*n + b
	b = (KEYSIZE-1)%160; // set b in: KEYSIZE-1 = 106*n + b
// step6
	C = 0;
	N = 2;
step7: // and step8
	mpz_set_ui(W, 0);
	for(k = 0; k <= n; k++) {
		mpz_add_ui(x, S, N); // x = S + N
		mpz_add_ui(x, x, k); // x = x + k = S + N + k
		mpz_mod(x, x, g2); // x = x mod g2 = S + N + k mod 2^gg
		s_size = 200;
		mpz_export((void*) s, &s_size, 1, 1, 0, 0, x); // export x to string s
		hash(z, s, s_size); // z = SHA(S + N + k mod 2^gg)
		if (k == n) {
			mpz_ui_pow_ui(y, 2, b); // y = 2^b
			mpz_mod(z, z, y); // z = z mod y = SHA(S + N + n mod 2^gg) mod 2^b
			mpz_ui_pow_ui(x, 2, 160*n); // x = 2^(160*n)
			mpz_mul(y, x, z);
				// y = x*z = 2^(160*n)*(SHA(S + N + n mod 2^gg) mod 2^b)
			mpz_add(W, W, y);
				// W = W + y = W + 2^(160*n)*(SHA(S + N + n mod 2^gg) mod 2^b)
		}
		else {
			mpz_ui_pow_ui(x, 2, 160*k); // x = 2^(160*k)
			mpz_mul(y, x, z); // y = x*z = 2^(160*k)*(SHA(S + N + k mod 2^gg))
			mpz_add(W, W, y);
				// W = W + y = W + 2^(160*k)*(SHA(S + N + k mod 2^gg))
		}
	}
	l = KEYSIZE-1;
	mpz_ui_pow_ui(x, 2, l); // x = 2^l = 2^(KEYSIZE-1)
	mpz_add(X, W, x); // X = W + x = W + 2^(KEYSIZE-1)
// step9
	mpz_mul_ui(y, q, 2); // y = 2*q
	mpz_mod(z, X, y); // z = X mod y = X mod 2*q
	mpz_sub_ui(z, z, 1); // z = z - 1 = (X mod 2*q) - 1
	mpz_sub(p, X, z); // p = X - z = X - ((X mod 2*q) - 1)
// step10
	if (mpz_cmp(p, x) < 0) goto step13;
//step11 and step12
	if (mpz_probab_prime_p(p, 50) > 0) goto step15;
step13:
	C = C + 1;
	N = N + n + 1;
// step14
	if (C == 4096) goto step1;
	else goto step7;
step15:
	/* Write S and C to file generate.seed */
	generate = fopen("generate.seed", "w");
	mpz_out_str(generate, 10, S);
	fprintf(generate, "\n%i\n", C);

	/*** Generate g ***/
	mpz_sub_ui(x, p, 1); // x = p-1
	do {
		mpz_urandomm(g, rand, x);
			// generate random number g between 0 and p-1
		mpz_divexact(y, x, q); // y = x/q = (p-1)/q
		mpz_powm(g, g, y, p); // g = g^y mod p = g^((p-1)/q) mod p
	} while (mpz_cmp_ui(g, 1) == 0);
		// generate new g if current one is not a generator

	/*** Generate a (private key) ***/
	do {
		mpz_urandomm(a, rand, q);
			// generate random number a between 0 and q-1
	} while (mpz_cmp_ui(a, 0) == 0); // generate new number a if a = 0

	/*** Calculate g^a ***/
	mpz_powm(ga, g, a, p); // ga = g^a mod p

	/*** Write keys to files ***/
	output_key(PUBLIC_FILE, p, q, g, ga);
	output_key(PRIVATE_FILE, p, q, g, a);

	/*** Clear variables ***/
	mpz_clear(S);
	mpz_clear(base);
	mpz_clear(g2);
	mpz_clear(U);
	mpz_clear(q);
	mpz_clear(W);
	mpz_clear(X);
	mpz_clear(p);
	mpz_clear(g);
	mpz_clear(a);
	mpz_clear(ga);
	mpz_clear(x);
	mpz_clear(y);
	mpz_clear(z);

	return 0;
}
