#include <fcntl.h>
#include <stdlib.h>
#include "hash.h"
#include "ds.h"
#include "dsa.h"
#include "random.h"

int main (int argc, char* argv[]) {
	/*** Declarations ***/
	mpz_t a, g, p, q, k, gk, r, s, x, y, digest;
	unsigned int buf_len = MAX_MESSAGE_SIZE;
	char buffer[buf_len];
	gmp_randstate_t rand;

	/*** Initialization of variables ***/
	mpz_init(a);
	mpz_init(g);
	mpz_init(p);
	mpz_init(q);
	mpz_init(k);
	mpz_init(gk);
	mpz_init(r);
	mpz_init(s);
	mpz_init(x);
	mpz_init(y);
	mpz_init(digest);

	/*** Initialization of the random number generator ***/
	gmp_randinit_default(rand);
	gmp_randseed_ui(rand, generate_seed());

	/*** Hash the message ***/
	FILE* message = stdin; // default to standard input
	if (argc >= 2) message = fopen(argv[1], "r"); // open given file for reading
	if (message == NULL) {
		printf("Could not open message file for reading!");
		exit(1);
	} // exit with error message if the file could not be opened for reading
	read_message(buffer, &buf_len, message, SIGNATURE_HEADER);
		// read message into buffer
	hash(digest, buffer, buf_len);
		// hash message, put result in variable digest
	fclose(message); // close the message file

	/*** Sign the message digest ***/
	input_key(p, q, g, a, PRIVATE_FILE); // read in the private key
	/* Choose random number k < p */
sign:
	do{mpz_urandomm(k, rand, p);} while(mpz_cmp_ui(k,0) == 0);
		// generate random number k between 1 and p-1
	/* Compute r */
	mpz_powm(gk, g, k, p); // gk = g^k mod p
	mpz_mod(r, gk, q); // r = gk mod q = g^k mod q
	if(mpz_cmp_ui(r, 0) == 0) goto sign;
		// find new k and try again if r = 0

	/* Compute s */
	mpz_invert(x, k, q); // x = 1/k mod q
	mpz_mul(y, a, r); // y = a*r
	mpz_add(y, digest, y); // y = digest + y = digest + a*r
	mpz_mod(y, y, q); // y = y mod q = (digest - a*r) mod q
	mpz_mul(s, x, y); // s = x*y = (1/k)*(digest - a*g^k)
	mpz_mod(s, s, q); // s = (1/k)*(digest - a*g^k) mod q
	if(mpz_cmp_ui(s, 0) == 0) goto sign;
		// find new k and try again if s = 0

	/*** Print message and signature ***/
	if (message == stdin) message = stdout;
		// determine if signature should be written to standard output or file
	else if (argc >= 3) message = fopen (argv[2],"w");
		// open destination file for writing
	else message = fopen (argv[1],"w"); // open file for writing if applicable
	if (message == NULL) {
		printf("Could not open message file for writing!");
		exit(1);
	} // exit with error message if the file could not be opened for writing
	fprintf(message, "%s", buffer);
	fprintf(message, SIGNATURE_HEADER);
		// write a standard string to indicate that the signature will follow
	mpz_out_str(message, 16, r);
		// write part 1 of signature to the message file (or standard output)
	fprintf(message, "\n");
	mpz_out_str(message, 16, s);
		// write part 2 of signature to the message file (or standard output)
	fprintf(message, "\n");
	fclose(message); // close the message file

	/*** Clear variables ***/
	mpz_clear(a);
	mpz_clear(g);
	mpz_clear(p);
	mpz_clear(q);
	mpz_clear(k);
	mpz_clear(gk);
	mpz_clear(r);
	mpz_clear(s);
	mpz_clear(x);
	mpz_clear(y);
	mpz_clear(digest);

	return 0;
}
