#include <fcntl.h>
#include <stdlib.h>
#include "hash.h"
#include "ds.h"
#include "dsa.h"

int main (int argc, char* argv[]) {

	/*** Declarations ***/
	unsigned int message_length = MAX_MESSAGE_SIZE;
	char message[message_length];
	FILE* input = stdin; // default to standard input
	mpz_t r, s, digest, ga, g, p, q, x, y, z;
	int ret_val;

	/*** Initializations ***/
	mpz_init(r);
	mpz_init(s);
	mpz_init(digest);
	mpz_init(ga);
	mpz_init(g);
	mpz_init(p);
	mpz_init(q);
	mpz_init(x);
	mpz_init(y);
	mpz_init(z);

	/*** Read in message and signature ***/
	if (argc >= 2) input = fopen(argv[1], "r");
		// if a file name was given, open the file for reading
	if (input == NULL) {
		printf("Could not open message file for reading!");
		exit(1);
	} // exit with error message if the file could not be opened for reading
	read_message(message, &message_length, input, SIGNATURE_HEADER);
		// read in the message
	read_signature(r, input); // read first part of signature
	read_signature(s, input); // read second part of signature
	fclose(input);

	/*** Signature verification ***/
	hash(digest, message, message_length); // hash the message
	input_key(p, q, g, ga, PUBLIC_FILE); // read in the public key
	mpz_invert(x, s, q); // x = 1/s mod q
	mpz_mul(y, x, digest); // y = x*digest = (1/s)*digest
	mpz_mod(y, y, q); // y = y mod q = (1/s)*digest mod q
	mpz_mul(z, x, r); // z = (1/s)*r
	mpz_mod(z, z, q); // z = z mod q = (1/s)*r mod q
	mpz_powm(x, g, y, p); // x = g^y mod p = g^(x*digest) mod p
	mpz_powm(y, ga, z, p); // y = ga^z mod p = (g^a)^((1/s)*r) mod p
	mpz_mul(z, x, y); // z = x*y = g^(x*digest) * (g^a)^((1/s)*r)
	mpz_mod(z, z, p);
		// z = z mod p = x*y = g^(x*digest) * (g^a)^((1/s)*r) mod p
	if (mpz_congruent_p(z, r, q) != 0) {
		printf("Signature verified\n");
		ret_val = 0;
	} // verify signature
	else {
		printf("Signature NOT verified!\n");
		ret_val = 1;
	} // don't verify the signature

	/*** Clear variables ***/
	mpz_clear(r);
	mpz_clear(s);
	mpz_clear(digest);
	mpz_clear(ga);
	mpz_clear(g);
	mpz_clear(p);
	mpz_clear(q);
	mpz_clear(x);
	mpz_clear(y);
	mpz_clear(z);

	return ret_val;
}
