#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#include "ecc.h"

/*** Function to read in public key from file ***/
void input_key_public (point* part1, point* part2, mpz_t part3, curve* part4, mpz_t part5, const char* filename) {
	FILE* infile = fopen(filename, "r"); // open the file for reading
	if (infile == NULL){
		fprintf(stderr,"Could not open %s for reading.\n", filename);
		exit(1);
	} // exit with error message if the file could not be opened for reading
	mpz_inp_raw(part1->x, infile); // read in x-coordinate of first point in key
	mpz_inp_raw(part1->y, infile); // read in y-coordinate of first point in key
	mpz_inp_raw(part2->x, infile); // read in x-coordinate of second point in key
	mpz_inp_raw(part2->y, infile); // read in y-coordinate of second point in key
	mpz_inp_raw(part3, infile); // read in the third part of the key
	mpz_inp_raw(part4->a, infile); // read in first part of the curve
	mpz_inp_raw(part4->b, infile); // read in second part of the curve
	mpz_inp_raw(part5, infile); // read in the fifth part of the key
	fclose(infile); // close the file
}

/*** Function to read in private key from file ***/
void input_key_private (mpz_t part1, point* part2, mpz_t part3, curve* part4, mpz_t part5, const char* filename) {
	FILE* infile = fopen(filename, "r"); // open the file for reading
	if (infile == NULL){
		fprintf(stderr,"Could not open %s for reading.\n", filename);
		exit(1);
	} // exit with error message if the file could not be opened for reading
	mpz_inp_raw(part1, infile); // read in the first part of the key
	mpz_inp_raw(part2->x, infile); // read in x-coordinate of the point in the key
	mpz_inp_raw(part2->y, infile); // read in y-coordinate of the point in the key
	mpz_inp_raw(part3, infile); // read in the third part of the key
	mpz_inp_raw(part4->a, infile); // read in first part of the curve
	mpz_inp_raw(part4->b, infile); // read in second part of the curve
	mpz_inp_raw(part5, infile); // read in the fifth part of the key
	fclose(infile); // close the file
}

/*** Function to write public key out to file ***/
void output_key_public (const char* filename, const point part1, const point part2, const mpz_t part3, const curve part4, const mpz_t part5) {
	FILE* outfile = fopen(filename, "w"); // open the file for writing
	if (outfile == NULL){
		fprintf(stderr,"Could not open %s for writing.\n", filename);
		exit(1);
	} // exit with error message if the file could not be opened for writing
	mpz_out_raw(outfile, part1.x); // write x-coordinate of first point to file
	mpz_out_raw(outfile, part1.y); // write y-coordinate of first point to file
	mpz_out_raw(outfile, part2.x); // write x-coordinate of second point to file
	mpz_out_raw(outfile, part2.y); // write y-coordinate of second point to file
	mpz_out_raw(outfile, part3); // write the third part of the key to the file
	mpz_out_raw(outfile, part4.a); // write first part of the curve to file
	mpz_out_raw(outfile, part4.b); // write second part of the curve to file
	mpz_out_raw(outfile, part5); // write the fifth part of the key to the file
	fclose(outfile); // close the file
}

/*** Function to write private key out to file ***/
void output_key_private (const char* filename, const mpz_t part1, const point part2, const mpz_t part3, const curve part4, const mpz_t part5) {
	FILE* outfile = fopen(filename, "w"); // open the file for writing
	if (outfile == NULL){
		fprintf(stderr,"Could not open %s for writing.\n", filename);
		exit(1);
	} // exit with error message if the file could not be opened for writing
	mpz_out_raw(outfile, part1); // write the first part of the key to the file
	mpz_out_raw(outfile, part2.x); // write x-coordinate of the point to file
	mpz_out_raw(outfile, part2.y); // write y-coordinate of the point to file
	mpz_out_raw(outfile, part3); // write the third part of the key to the file
	mpz_out_raw(outfile, part4.a); // write first part of the curve to file
	mpz_out_raw(outfile, part4.b); // write second part of the curve to file
	mpz_out_raw(outfile, part5); // write the fifth part of the key to the file
	fclose(outfile); // close the file
}

void point_init (point* P) {
	mpz_init(P->x);
	mpz_init(P->y);
}

void point_clear (point* P) {
	mpz_clear(P->x);
	mpz_clear(P->y);
}

void curve_init (curve* E) {
	mpz_init(E->a);
	mpz_init(E->b);
}

void curve_clear (curve* E) {
	mpz_clear(E->a);
	mpz_clear(E->b);
}

/*** Set dP to be the point at infinity ***/
void point_set_infinity (point* dP) {
	mpz_set_si(dP->x, -1);
	mpz_set_si(dP->y, -1);
}

/*** Return non-zero if P is the point at infinity, 0 otherwise ***/
int point_test_infinity (point P) {
	if ((mpz_cmp_si(P.x, -1) == 0) && (mpz_cmp_si(P.y, -1)) == 0) return 1;
	else return 0;
}

/*** Function to calculate k*P ***/
void point_multiply (point* dP, mpz_t k, point P, curve E, mpz_t p) {
	if (point_test_infinity(P) != 0) {
		point_set_infinity(dP); // k*P = P if P is point at infinity
	}

	else {
		point temp; point_init(&temp);
		int i;
		unsigned int length = mpz_sizeinbase(k, 2);
		point pointlist[length];

		point_init(&pointlist[0]);

		mpz_set(pointlist[0].x, P.x);
		mpz_set(pointlist[0].y, P.y);
		for (i = 1; i < length; i++) {
			point_init(&pointlist[i]);
			point_double(&pointlist[i], pointlist[i-1], E, p);
		}
		i = mpz_scan1(k, 0);
		mpz_set(dP->x, pointlist[i].x);
		mpz_set(dP->y, pointlist[i].y);
		i = mpz_scan1(k, i+1); // find next 1
		while (i < length) {
			mpz_set(temp.x, dP->x);
			mpz_set(temp.y, dP->y);
			point_add (dP, temp, pointlist[i], E, p);
			i = mpz_scan1(k, i+1);
		}

		for (i=0; i<length; i++) point_clear(&pointlist[i]);
		point_clear(&temp);
	}
}

/*** Function to calculate 2*P ***/
void point_double (point* dP, point P, curve E, mpz_t p) {
	if (point_test_infinity(P) != 0) {
		mpz_set(dP->x, P.x);
		mpz_set(dP->y, P.y); // 2*P = P if P is point at infinity
	}
	else if (mpz_cmp_ui(P.y, 0) == 0) point_set_infinity(dP);
		// 2*P = point at infinity if P has y coordinate = 0 (y = -y)

	else {
		mpz_t lambda, u, v;
		mpz_init(lambda); mpz_init(u); mpz_init(v); // init

		/* Calculate lambda */
		mpz_powm_ui(u, P.x, 2, p); // u = (P.x)^2 mod p
		mpz_mul_ui(u, u, 3); // u = 3*u = 3*(P.x)^2
		mpz_add(u, u, E.a); // u = u + a = 3*(P.x)^2 + a
		mpz_mod(u, u, p); // u = u mod p = 3*(P.x)^2 + a mod p
		mpz_mul_ui(v, P.y, 2); // v = 2*y
		mpz_invert(v, v, p); // v = 1/v mod p = 1/(2*y) mod p
		mpz_mul(lambda, u, v); // lambda = u*v = (3*(P.x)^2 + a)/(2*(P.y))
		mpz_mod(lambda, lambda, p); // lambda = (3*(P.x)^2 + a)/(2*(P.y)) mod p

		/* Calculate dP->x */
		mpz_powm_ui(u, lambda, 2, p); // u = lambda^2 mod p
		mpz_add(v, P.x, P.x); // v = P.x + P.x
		mpz_sub(dP->x, u, v); // dP->x = u - v = lambda^2 - 2*(P.x)
		mpz_mod(dP->x, dP->x, p); // dP->x = dP->x mod p

		/* Calculate dP->y */
		mpz_sub(u, P.x, dP->x); // u = P.x - dP->x
		mpz_mul(u, lambda, u); // u = lambda*u = lambda*(P.x - dP->x)
		mpz_sub(dP->y, u, P.y); // dP->y = u - P.y =  lambda*(P.x - dP->x) - P.y
		mpz_mod(dP->y, dP->y, p); // dP->y = dP->y mod p

		mpz_clear(lambda); mpz_clear(u); mpz_clear(v); // clear
	}
}

/*** Function to add points P and Q on the curve E over Fp ***/
void point_add (point* dP, point P, point Q, curve E, mpz_t p) {
	if (point_test_infinity(P) != 0) {
		mpz_set(dP->x, Q.x);
		mpz_set(dP->y, Q.y); // P + Q = Q if P is point at infinity
	}

	else if (point_test_infinity(Q) != 0) {
		mpz_set(dP->x, P.x);
		mpz_set(dP->y, P.y); // P + Q = P if Q is point at infinity
	}

	else if ((mpz_cmp(P.x, Q.x) == 0) && (mpz_cmp(P.y, Q.y) == 0)) {
		point_double (dP, P, E, p);
	} // use point_double function if P = Q

	else if ((mpz_cmp(P.x, Q.x) == 0) && (mpz_cmp(P.y, Q.y) != 0)) {
		point_set_infinity(dP);
	} // P + Q = the point at infinity if P.x = Q.x and P.y = -P.y

	else {
		mpz_t lambda, u, v;
		mpz_init(lambda); mpz_init(u); mpz_init(v); // init

		/* Calculate lambda */
		mpz_sub(u, Q.y, P.y); // u = Q.y - P.y
		mpz_mod(u, u, p); // u = u mod p = Q.y - P.y mod p
		mpz_sub(v, Q.x, P.x); // v = Q.x - P.x
		mpz_invert(v, v, p); // v = 1/v mod p = 1/(Q.x - P.x) mod p
		mpz_mul(lambda, u, v); // lambda = u*v = (Q.y - P.y)/(Q.x - P.x)
		mpz_mod(lambda, lambda, p); // lambda = lambda mod p

		/* Calculate dP->x */
		mpz_powm_ui(u, lambda, 2, p); // u = lambda^2 mod p
		mpz_add(v, P.x, Q.x); // v = P.x + Q.x
		mpz_sub(dP->x, u, v); // dP->x = u - v = lambda^2 - (P.x + Q.x)
		mpz_mod(dP->x, dP->x, p); // dP->x = dP->x mod p

		/* Calculate dP->y */
		mpz_sub(u, P.x, dP->x); // u = P.x - dP->x
		mpz_mul(u, lambda, u); // u = lambda*u = lambda*(P.x - dP->x)
		mpz_sub(dP->y, u, P.y); // dP->y = u - P.y =  lambda*(P.x - dP->x) - P.y
		mpz_mod(dP->y, dP->y, p); // dP->y = dP->y mod p

		mpz_clear(lambda); mpz_clear(u); mpz_clear(v); // clear
	}
}

