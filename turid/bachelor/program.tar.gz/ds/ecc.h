#ifndef ECC_H
#define ECC_H

#include <gmp.h>

#define FIELDSIZE 192
#define PUBLIC_FILE "ecc_public.key"
#define PRIVATE_FILE "ecc_private.key"

// message must be < 100K
#define MAX_MESSAGE_SIZE (100*1024)
#define SIGNATURE_HEADER "\n-----BEGIN ECC SIGNATURE-----\n"

typedef struct {
	mpz_t x;
	mpz_t y;
} point;

typedef struct {
	mpz_t a;
	mpz_t b;
} curve;

void point_init (point* P);
void point_clear (point* P);

void curve_init (curve* E);
void curve_clear (curve* E);

/*** Set dP to be the point at infinity ***/
void point_set_infinity (point* dP);

/*** Return non-zero if P is infinity, 0 otherwise ***/
int point_test_infinity (point P);

/*** Function to read in public key from file ***/
void input_key_public (point* part1, point* part2, mpz_t part3, curve* part4, mpz_t part5, const char* filename);

/*** Function to read in private key from file ***/
void input_key_private (mpz_t part1, point* part2, mpz_t part3, curve* part4, mpz_t part5, const char* filename);

/*** Function to write public key out to file ***/
void output_key_public (const char* filename, const point part1, const point part2, const mpz_t part3, const curve part4, const mpz_t part5);

/*** Function to write private key out to file ***/
void output_key_private (const char* filename, const mpz_t part1, const point part2, const mpz_t part3, const curve part4, const mpz_t part5);

/*** Function to calculate k*P
     k is an integer in Fp
     P is a point on the elliptic curve (over Fp) ***/
void point_multiply (point* kP, mpz_t k, point P, curve E, mpz_t p);

/*** Function to calculate 2*P
	 P is a point on the curve E (over Fp) ***/
void point_double (point* dP, point P, curve E, mpz_t p);

/*** Function to add points P and Q on the curve E over Fp ***/
void point_add (point* dP, point P, point Q, curve E, mpz_t p);

#endif // ECC_H
