#include <fcntl.h>
#include <stdlib.h>
#include "hash.h"
#include "ds.h"
#include "ecc.h"
#include "random.h"

int main (int argc, char* argv[]) {
	/*** Declarations ***/
	mpz_t p, q, k, r, s, x, u, v, digest;
	point P, Q;
	curve E;
	unsigned int buf_len = MAX_MESSAGE_SIZE;
	char buffer[buf_len];
	gmp_randstate_t rand;

	/*** Initialization of variables ***/
	mpz_init(p);
	mpz_init(q);
	mpz_init(k);
	mpz_init(r);
	mpz_init(s);
	mpz_init(x);
	mpz_init(u);
	mpz_init(v);
	mpz_init(digest);

	point_init(&P);
	point_init(&Q);
	curve_init(&E);

	/*** Initialization of the random number generator ***/
	gmp_randinit_default(rand);
	gmp_randseed_ui(rand, generate_seed());

	/*** Hash the message ***/
	FILE* message = stdin; // default to standard input
	if (argc >= 2) message = fopen(argv[1], "r"); // open given file for reading
	if (message == NULL) {
		printf("Could not open message file for reading!");
		exit(1);
	} // exit with error message if the file could not be opened for reading
	read_message(buffer, &buf_len, message, SIGNATURE_HEADER);
		// read message into buffer
	hash(digest, buffer, buf_len);
		// hash message, put result in variable digest
	fclose(message); // close the message file

	/*** Sign the message digest ***/
	input_key_private(x, &P, q, &E, p, PRIVATE_FILE); // read in the private key

step1:
	/* Choose random number k < q */
	do { mpz_urandomm(k, rand, q); } while (mpz_cmp_ui(k,0) == 0);
		// generate random number k between 1 and q-1
// step2:
	/* Compute r */
	point_multiply(&Q, k, P, E, p); // Q = k*P
	mpz_set(r, Q.x); // r = Q.x
	mpz_mod(r, r, q); // r = r mod p = Q.x mod q
	if(mpz_cmp_ui(r, 0) == 0) goto step1;
// step3:
	/* Compute 1/k */
	mpz_invert(u, k, q); // u = 1/k mod q
// step4:
	/* Compute s */
	mpz_mul(v, x, r); // v = x*r
	mpz_add(v, digest, v); // v = digest + x*r
	mpz_mul(s, u, v); // s = u*v = (1/k)*(digest + x*r)
	mpz_mod(s, s, q); // s = s mod q = (1/k)*(digest + x*r) mod q
	if (mpz_cmp_ui(s, 0) == 0) goto step1;


	/*** Print message and signature ***/
	if (message == stdin) message = stdout;
		// determine if signature should be written to standard output or file
	else if (argc >= 3) message = fopen (argv[2],"w");
		// open destination file for writing
	else message = fopen (argv[1],"w"); // open file for writing if applicable
	if (message == NULL) {
		printf("Could not open message file for writing!");
		exit(1);
	} // exit with error message if the file could not be opened for writing
	fprintf(message, "%s", buffer);
	fprintf(message, SIGNATURE_HEADER);
		// write a standard string to indicate that the signature will follow
	mpz_out_str(message, 16, r);
		// write part 1 of signature to the message file (or standard output)
	fprintf(message, "\n");
	mpz_out_str(message, 16, s);
		// write part 2 of signature to the message file (or standard output)
	fprintf(message, "\n");
	fclose(message); // close the message file

	/*** Clear variables ***/
	mpz_clear(p);
	mpz_clear(q);
	mpz_clear(k);
	mpz_clear(r);
	mpz_clear(s);
	mpz_clear(x);
	mpz_clear(u);
	mpz_clear(v);
	mpz_clear(digest);

	point_clear(&P);
	point_clear(&Q);
	curve_clear(&E);

	return 0;
}
