#include <fcntl.h>
#include <stdlib.h>
#include "hash.h"
#include "ds.h"
#include "ecc.h"

int main (int argc, char* argv[]) {

	/*** Declarations ***/
	unsigned int message_length = MAX_MESSAGE_SIZE;
	char message[message_length];
	FILE* input = stdin; // default to standard input
	mpz_t p, q, r, s, digest, w, u1, u2, v, y, z;
	point P, Q, u1P, u2Q, V;
	curve E;
	int ret_val;

	/*** Initializations ***/
	mpz_init(p);
	mpz_init(q);
	mpz_init(r);
	mpz_init(s);
	mpz_init(digest);
	mpz_init(w);
	mpz_init(u1);
	mpz_init(u2);
	mpz_init(v);
	mpz_init(y);
	mpz_init(z);

	point_init(&P);
	point_init(&Q);
	point_init(&u1P);
	point_init(&u2Q);
	point_init(&V);
	curve_init(&E);

	/*** Read in message and signature ***/
	if (argc >= 2) input = fopen(argv[1], "r");
		// if a file name was given, open the file for reading
	if (input == NULL) {
		printf("Could not open message file for reading!");
		exit(1);
	} // exit with error message if the file could not be opened for reading
	read_message(message, &message_length, input, SIGNATURE_HEADER);
		// read in the message
	read_signature(r, input); // read first part of signature
	read_signature(s, input); // read second part of signature
	fclose(input);

	/*** Signature verification ***/
	hash(digest, message, message_length); // hash the message
	input_key_public(&Q, &P, q, &E, p, PUBLIC_FILE); // read in the public key
	if ((mpz_cmp(q, r) < 0) || (mpz_cmp(q, s) < 0)) {
		printf("Invalid signature\n");
		return 1;
	}
	mpz_invert(w, s, q); // w = 1/s mod q
	mpz_mul(u1, digest, w); // u1 = digest*w = digest*(1/s)
	mpz_mod(u1, u1, q); // u1 = u1 mod q = digest*(1/s) mod q
	mpz_mul(u2, r, w); // u2 = r*w = r*(1/s)
	mpz_mod(u2, u2, q); // u2 = u2 mod q = r*(1/s) mod q
	point_multiply(&u1P, u1, P, E, p); // u1P = u1*P
	point_multiply(&u2Q, u2, Q, E, p); // u2Q = u2*Q
	point_add(&V, u1P, u2Q, E, p); // V = u1P + u2Q
	mpz_set(v, V.x); // v = V.x

	if (mpz_congruent_p(v, r, q) != 0) {
		printf("Signature verified\n");
		ret_val = 0;
	} // verify signature
	else {
		printf("Signature NOT verified!\n");
		ret_val = 1;
	} // don't verify the signature

	/*** Clear variables ***/
	mpz_clear(p);
	mpz_clear(q);
	mpz_clear(r);
	mpz_clear(s);
	mpz_clear(digest);
	mpz_clear(w);
	mpz_clear(u1);
	mpz_clear(u2);
	mpz_clear(v);
	mpz_clear(y);
	mpz_clear(z);

	point_clear(&P);
	point_clear(&Q);
	point_clear(&u1P);
	point_clear(&u2Q);
	point_clear(&V);
	curve_clear(&E);

	return ret_val;
}
