#include "hash.h"

#include <stdlib.h>
#include <mhash.h>

/*** Create a digest of the input using Secure Hash Algorithm ***/
void hash (mpz_t digest, char* input, unsigned int length) {
	int i;
	MHASH td; // mhash object
	unsigned char *hash;
	unsigned char hashstr[2*mhash_get_block_size(MHASH_SHA1)+1];

	td = mhash_init(MHASH_SHA1); // initialize mhash object
	if (td == MHASH_FAILED) exit(1); // abort on error

	mhash(td, input, length); // add input string to hash object

	hash = mhash_end(td); // get hash digest
	for (i = 0; i < mhash_get_block_size(MHASH_SHA1); i++)
		sprintf(&(hashstr[2*i]), "%.2x", hash[i]);
		// print hash digest in hex
	mpz_set_str(digest, hashstr, 16); // return hash digest as GMP integer
}
