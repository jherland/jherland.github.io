#ifndef HASH_H
#define HASH_H

#include <stdio.h>
#include <gmp.h>

/*** Create a digest of the input using Secure Hash Algorithm ***/
void hash (mpz_t digest, char* input, unsigned int length);

#endif // HASH_H
