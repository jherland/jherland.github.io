#include "random.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

/* Generate seed for random number generator */
unsigned long int generate_seed () {
	/* Declarations */
	unsigned long int randnum;
	int fd = open(RANDSOURCE, O_RDONLY);

	if (fd == -1) {
		fprintf(stderr,"Could not open %s for reading.\n",RANDSOURCE);
		exit(1);
		// If the file is null, print error message and exit
	}
	read(fd, &randnum, sizeof(unsigned long int));
	return randnum; //return an unsigned long int with data from /dev/random
}
