#ifndef RANDOM_H
#define RANDOM_H

#define RANDSOURCE "/dev/random"

/* Generate seed for random number generator */
unsigned long int generate_seed ();

#endif // RANDOM_H
