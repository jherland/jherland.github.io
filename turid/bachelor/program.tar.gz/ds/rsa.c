#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#include "rsa.h"

/*** Function to read in keys from file ***/
void input_key (mpz_t part1, mpz_t part2, const char* filename) {
	FILE* infile = fopen(filename, "r"); // open the file for reading
	if (infile == NULL){
		fprintf(stderr,"Could not open %s for reading.\n", filename);
		exit(1);
	} // exit with error message if the file could not be opened for reading
	mpz_inp_raw(part1, infile); // read in the first part of the key
	mpz_inp_raw(part2, infile); // read in the second part of the key
	fclose(infile); // close the file
}

/*** Function to write keys out to file ***/
void output_key (const char* filename, const mpz_t part1, const mpz_t part2) {
	FILE* outfile = fopen(filename, "w"); // open the file for writing
	if (outfile == NULL){
		fprintf(stderr,"Could not open %s for writing.\n", filename);
		exit(1);
	} // exit with error message if the file could not be opened for writing
	mpz_out_raw(outfile, part1); // write the first part of the key to the file
	mpz_out_raw(outfile, part2); // write the second part of the key to the file
	fclose(outfile); // close the file
}
