#include "rsa.h"
#include "random.h"

/*** Generate keys for RSA signature ***/
int main (int argc, char* argv[]) {

	/*** Declarations ***/
	mpz_t base_p, base_q, p, q, n, phi, d, e, x, y, z;
	gmp_randstate_t rand;

	/*** Initialization of variables ***/
	mpz_init(base_p);
	mpz_init(base_q);
	mpz_init(p);
	mpz_init(q);
	mpz_init(n);
	mpz_init(phi);
	mpz_init(d);
	mpz_init(e);
	mpz_init(x);
	mpz_init(y);
	mpz_init(z);

	/*** Initialization of the random number generator ***/
	gmp_randinit_default(rand);
	gmp_randseed_ui(rand, generate_seed());

	/*** Generate random primes ***/
	mpz_ui_pow_ui(base_p, 2, (KEYSIZE/2)-5);
		// set integer base_p to 2^((KEYSIZE/2)-5)
	mpz_ui_pow_ui(base_q, 2, (KEYSIZE/2)+5);
		// set integer base_q to 2^((KEYSIZE/2)+5)
	do {
		mpz_urandomb(p, rand, (KEYSIZE/2)-5);
			//create random number p between 0 and 2^((KEYSIZE/2)-5)
		mpz_add(p, p, base_p);
			// make sure that p is at least (KEYSIZE/2)-5 bits long
		mpz_mul_ui(p, p, 2); // p = 2*p
		mpz_add_ui(p, p, 1); // p = p + 1 = 2p + 1
	} while(mpz_probab_prime_p(p, 50) == 0); // find new p if p is not prime
	do {
		mpz_urandomb(q, rand, (KEYSIZE/2)+5);
			//create random number q between 0 and 2^((KEYSIZE/2)+5)
		mpz_add(q, q, base_q);
			// make sure that q is at least (KEYSIZE/2)+5 bits long
		mpz_mul_ui(q, q, 2); // q = 2*q
		mpz_add_ui(q, q, 1); // q = q + 1 = 2q + 1
	} while(mpz_probab_prime_p(q, 50) == 0); // find new q if q is not prime

	/*** Calculate RSA modulus ***/
	mpz_mul(n, p, q); // n = p*q

	/*** Calculate phi(n) ***/
	// x and y are used as local temporary variables
	mpz_add_ui(x, n, 1); // x = n + 1
	mpz_add(y, p, q); // y = p + q
	mpz_sub(phi, x, y); // phi(n) = (p-1)*(q-1) = (n+1) - (p+q) = x - y

	/*** Generate public decryption exponent d ***/
	// x and y are used as local temporary variables
	do {
		mpz_urandomb(d, rand, 700); // create random number d < 2^700
		mpz_ui_pow_ui(x, 2, 500);
		while (mpz_cmp(d,x) < 0) mpz_urandomb(d, rand, 700);
			// make sure d >= 2^500
		if (mpz_even_p(d)) mpz_add_ui(d, d, 1); // make sure that d is odd
		mpz_gcd(y, d, phi); // y = gcd(d, phi(n))
		while (mpz_cmp_ui (y, 1) != 0) {
			mpz_add_ui(d, d, 2); // d = d + 2
			mpz_gcd(y, d, phi); // y = gcd(d, phi(n))
		} // d is now relatively prime to phi(n)

	/*** Calculate private encryption exponent e ***/
		mpz_invert(e, d, phi);
		mpz_tdiv_q_ui(x, n, 4); // x = n/4
	} while(mpz_cmp(e, x) < 0); // generate new d and e if e < (1/4)*n

	/*** Write keys to files ***/
	output_key(PUBLIC_FILE, d, n);
	output_key(PRIVATE_FILE, e, n);


	/*** Clearing ***/
	mpz_clear(base_p);
	mpz_clear(base_q);
	mpz_clear(p);
	mpz_clear(q);
	mpz_clear(n);
	mpz_clear(phi);
	mpz_clear(d);
	mpz_clear(e);
	mpz_clear(x);
	mpz_clear(y);
	mpz_clear(z);
	gmp_randclear(rand);

	return 0;
}
