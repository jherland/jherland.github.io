#include <fcntl.h>
#include <stdlib.h>
#include "hash.h"
#include "ds.h"
#include "rsa.h"

int main (int argc, char* argv[]) {
	/*** Declarations ***/
	mpz_t e, n, digest, signature;
	unsigned int buf_len = MAX_MESSAGE_SIZE;
	char buffer[buf_len];

	/*** Initialization of variables ***/
	mpz_init(e); mpz_init(n); mpz_init(digest); mpz_init(signature);

	/*** Hash the message ***/
	FILE* message = stdin; // default to standard input
	if (argc >= 2) message = fopen(argv[1], "r"); // open given file for reading
	if (message == NULL) {
		printf("Could not open message file for reading!");
		exit(1);
	} // exit with error message if the file could not be opened for reading
	read_message(buffer, &buf_len, message, SIGNATURE_HEADER); // read message into buffer
	hash(digest, buffer, buf_len);
		// hash message, put result in variable digest
	fclose(message); // close the message file

	/*** Sign the message digest ***/
	input_key(e, n, PRIVATE_FILE); // read in the private key
	mpz_powm(signature, digest, e, n); // sign the digest

	/*** Print message and signature ***/
	if (message == stdin) message = stdout;
		// determine if signature should be written to standard output or file
	else if (argc >= 3) message = fopen (argv[2],"w");
		// open destination file for writing
	else message = fopen (argv[1],"w"); // open file for writing if applicable
	if (message == NULL) {
		printf("Could not open message file for writing!");
		exit(1);
	} // exit with error message if the file could not be opened for writing
	fprintf(message, "%s", buffer);
	fprintf(message, SIGNATURE_HEADER);
		// write a standard string to indicate that the signature will follow
	mpz_out_str(message, 16, signature);
		// write the signature to the message file (or standard output)
	fprintf(message, "\n");
	fclose(message); // close the message file

	/*** Clear variables ***/
	mpz_clear(e);
	mpz_clear(n);
	mpz_clear(digest);
	mpz_clear(signature);

	return 0;
}
