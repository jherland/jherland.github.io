#include <fcntl.h>
#include <stdlib.h>
#include "hash.h"
#include "ds.h"
#include "rsa.h"

int main (int argc, char* argv[]) {

	/*** Declarations ***/
	unsigned int message_length = MAX_MESSAGE_SIZE;
	char message[message_length];
	FILE* input = stdin; // default to standard input
	mpz_t signature, digest, d, n, sig_digest;
	int ret_val;

	/*** Initializations ***/
	mpz_init(signature);
	mpz_init(digest);
	mpz_init(d);
	mpz_init(n);
	mpz_init(sig_digest);

	/*** Read in message and signature ***/
	if (argc >= 2) input = fopen(argv[1], "r");
		// if a file name was given, open the file for reading
	if (input == NULL) {
		printf("Could not open message file for reading!");
		exit(1);
	} // exit with error message if the file could not be opened for reading
	read_message(message, &message_length, input, SIGNATURE_HEADER);
		// read in the message
	read_signature(signature, input); // read in the signature
	fclose(input);

	/*** Signature verification ***/
	hash(digest, message, message_length); // hash the message
	input_key(d, n, PUBLIC_FILE); // read in the public key
	mpz_powm(sig_digest, signature, d, n); // decrypt signature
	if (mpz_cmp(digest, sig_digest) == 0) {
		printf("Signature verified\n");
		ret_val = 0;
	} // verify signature if it matches the hashed message
	else {
		printf("Signature NOT verified!\n");
		ret_val = 1;
	} // don't verify the signature if it doesn't match the hashed message

	/*** Clear variables ***/
	mpz_clear(signature);
	mpz_clear(digest);
	mpz_clear(d);
	mpz_clear(n);
	mpz_clear(sig_digest);

	return ret_val;
}
